#pragma once

#include <map>
#include <string>

#include "SpriteSheet.h"

namespace Engineering2D
{
	class Scene;
	
	class TextureManager
	{
	public:
		TextureManager(Scene* scene);
		~TextureManager();

		SpriteSheet* CreateTexture(const std::string& textureFilePath);
		
	private:
		Scene* m_scene;
		std::map<const std::string, SpriteSheet*> spriteSheets;
	};
}
