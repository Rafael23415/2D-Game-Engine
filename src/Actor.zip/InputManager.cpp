﻿#include "InputManager.h"

#include "Scene.h"

namespace Engineering2D
{
    InputManager::InputManager(Scene* scene) : m_scene(scene)
    {
    }

    void InputManager::ProcessInput()
    {
        while (SDL_PollEvent(&ev)) {
            // Getting the events
            if (ev.type == SDL_EVENT_QUIT)
            {
                m_scene->ShutDown();
            }
        }
    }
    void InputManager::BindAction(const std::string& actionName, Key keybind)
    {
        //keybinds[actionName] = keybind;
    }

    bool InputManager::IsPressed(const std::string& actionName)
    {
        return false;
    }
}
