﻿#include "Actor.h"

namespace Engineering2D
{
    Actor::Actor(Vector2D position, Vector2D scale, SpriteSheet* spriteSheet) : m_position(position), m_scale(scale), m_isActive(true), m_spriteSheet(spriteSheet)
    {
    }
    
    void Actor::SetActive(bool active)
    {
        m_isActive = active;
    }

    bool Actor::IsActive() const
    {
        return m_isActive;
    }
}
