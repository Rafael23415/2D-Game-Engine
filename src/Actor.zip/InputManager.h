﻿#pragma once

#include <SDL3/SDL_events.h>
#include <map>
#include <string>

namespace Engineering2D
{
    class Scene;
    
    enum Key {

    };

    /**
     * 
     */
    class InputManager
    {
    public:
        InputManager(Scene* scene);
        ~InputManager() = default;
        
        void ProcessInput();
        void BindAction(const std::string& actionName, Key keybind);
        bool IsPressed(const std::string& actionName);
    
    private:
        Scene* m_scene;
        
        SDL_Event ev;

        std::map<const std::string&, SDL_Keycode> keybinds;
    };
}
